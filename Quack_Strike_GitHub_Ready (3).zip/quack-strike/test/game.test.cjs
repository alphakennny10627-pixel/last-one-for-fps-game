/** Dependency-free regression tests for the actual inline game code. Node 18+. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { spawnSync } = require('node:child_process');
const html = fs.readFileSync(path.join(__dirname, '..', 'dist', 'index.html'), 'utf8');
const script = html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
function section(start, end) {
  const a = script.indexOf(start), b = script.indexOf(end, a);
  assert(a >= 0 && b > a, `Missing source section: ${start}`);
  return script.slice(a, b);
}
function economy() {
  const c = { state: 'shop', cash: 3000, player: { hp: 60 }, ammo: 8,
    reserve: 80, reloadLeft: 0, smokeCount: 2, shieldEnergy: 50,
    mouseDown: false, aim: false, CONFIG: { magazine: 25 },
    upgrades: { rifle: false, fists: false }, sound: { play() {} },
    updateHUD() {}, shopUI: { shopNotice: { textContent: '' } } };
  vm.createContext(c);
  vm.runInContext(section('const EQUIPMENT=', 'const gearSlots='), c);
  c.renderLoadout = () => {}; c.renderShop = () => {};
  vm.runInContext(section('const SHOP=[', 'const shopUI='), c);
  vm.runInContext(section('function shopUnavailable(', 'function renderShop('), c);
  vm.runInContext(section('function buyItem(', 'function selectShopTab('), c);
  return c;
}
test('complete game JavaScript parses as an ES module', () => {
  const result = spawnSync(process.execPath, ['--input-type=module', '--check'],
    { input: script, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
});
test('shop charges once, rejects unowned equipment and preserves ammo on equip', () => {
  const c = economy();
  assert.equal(c.equipOwnedItem('talon'), false);
  assert.equal(c.buyItem('talon'), true);
  assert.equal(c.cash, 1800);
  assert.equal(c.buyItem('talon'), false);
  assert.equal(c.cash, 1800);
  assert.equal(c.equipOwnedItem('talon'), true);
  assert.equal(c.gunStats().body, 75);
  assert.equal(c.ammo, 8);
  assert.equal(c.buyItem('bulwark'), true);
  assert.equal(c.equipOwnedItem('bulwark'), true);
  assert.equal(c.shieldCapacity(), 175);
  assert.equal(c.shieldEnergy, 87.5);
  assert.equal(c.equipOwnedItem('aegis'), true);
  assert.equal(c.shieldEnergy, 50);
  assert.equal(c.buyItem('shock'), true);
  assert.equal(c.equipOwnedItem('shock'), true);
  assert.equal(c.fistStats().damage, 110);
  c.upgrades.fists = c.upgrades.rifle = true;
  assert.equal(c.fistStats().damage, 135);
  assert.equal(c.gunStats().body, 90);
  assert.equal(c.gunStats().head, 210);
});
test('consumables respect caps and purchases require coins and shop state', () => {
  const c = economy();
  c.cash = 150;
  assert.equal(c.buyItem('medkit'), true);
  assert.equal(c.cash, 0);
  assert.equal(c.player.hp, 100);
  assert.equal(c.buyItem('ammo'), false);
  c.cash = 1000;
  assert.equal(c.buyItem('medkit'), false);
  assert.equal(c.cash, 1000);
  c.smokeCount = 5;
  assert.equal(c.buyItem('smoke'), false);
  c.reserve = 190; c.ammo = 0; c.reloadLeft = 1;
  assert.equal(c.buyItem('ammo'), true);
  assert.equal(c.ammo, 25);
  assert.equal(c.reserve, 200);
  assert.equal(c.reloadLeft, 0);
  c.state = 'playing';
  assert.equal(c.buyItem('shock'), false);
  assert.equal(c.equipOwnedItem('kestrel'), false);
});
test('9 turns exactly 180 degrees, preserving pitch and respecting pause', () => {
  const c = { state: 'playing', player: { yaw: .7, pitch: .4 },
    camera: { rotation: { set(p, y) { c.cameraYaw = y; c.cameraPitch = p; } }, updateMatrixWorld() {} } };
  vm.createContext(c);
  vm.runInContext(section('function quickTurn(){', 'function dash(){'), c);
  c.quickTurn();
  assert(Math.abs(c.player.yaw - (.7 + Math.PI)) < 1e-10);
  assert.equal(c.player.pitch, .4);
  assert.equal(c.cameraYaw, c.player.yaw);
  c.state = 'paused'; const yaw = c.player.yaw;
  c.quickTurn(); assert.equal(c.player.yaw, yaw);
});

test('device selection enables deployment and switches controls without resetting the run', () => {
  const buttons = ['computer','mobile'].map(mode => ({ dataset: {device: mode}, setAttribute(k,v) {this[k]=v;} }));
  const help = {};
  const c = { deviceSelected: false, touchMode: false, mouseDown: true, padFire: true, padAim: true,
    keys: new Set(['KeyW']), resetTouch() {this.resets=(this.resets||0)+1;}, setCompatLook(){},
    ui: {start: {disabled:true}}, document: {exitPointerLock(){}, body:{classList:{toggle(k,v){c.mobileClass=v;}}},
    querySelectorAll(){return buttons;}, getElementById(){return help;} } };
  vm.createContext(c);
  vm.runInContext(section('function selectDevice(mode){', "for(const button of document.querySelectorAll('[data-device]'))"), c);
  c.selectDevice('mobile');
  assert.equal(c.touchMode,true); assert.equal(c.mobileClass,true); assert.equal(c.ui.start.disabled,false);
  assert.equal(c.keys.size,0); assert.equal(c.mouseDown,false); assert.equal(buttons[1]['aria-pressed'],'true');
  c.selectDevice('computer');
  assert.equal(c.touchMode,false); assert.equal(c.mobileClass,false); assert.equal(buttons[0]['aria-pressed'],'true');
  c.selectDevice('invalid'); assert.equal(c.touchMode,false);
});

test('scoring ledger totals bonuses, keeps coins independent and resets the run', () => {
  const elements = {};
  const c = {score:0,cash:0,addFeed(){},clearTimeout(){},setTimeout(){return 1;},
    document:{getElementById(id){return elements[id] ||= {};}}};
  vm.createContext(c);
  vm.runInContext(section('const SCORE_RULES=', 'const CONFIG='),c);
  assert.equal(c.awardScore('duck'),100);
  assert.equal(c.awardScore('duck',true),200);
  assert.equal(c.awardScore('boss',true),1100);
  assert.equal(c.awardScore('round'),500);
  c.cash=250;assert.equal(c.awardScore('gold'),250);
  assert.equal(c.score,2150);assert.equal(c.cash,250);
  c.cash-=150;c.refreshScoreSummary();assert.equal(c.score,2150);
  assert.match(c.scoreBreakdown(),/Duck eliminations: 2 × 100 = 200/);
  assert.match(c.scoreBreakdown(),/Finishing headshots: 2 × 100 = 200/);
  assert.match(c.scoreBreakdown(),/TOTAL: 2150 POINTS · 100 COINS AVAILABLE/);
  assert.equal(c.awardScore('invalid'),0);assert.equal(c.score,2150);
  c.resetScore();assert.equal(c.score,0);assert.match(c.scoreBreakdown(),/Rounds cleared: 0 × 500 = 0/);
  assert.equal(elements.scoreToast.hidden,true);
});

test('player names restore, default safely, persist and isolate game shortcuts', () => {
  const listeners={},input={value:'',addEventListener(t,f){listeners[t]=f;}},tag={};
  const c={document:{getElementById(id){return id==='playerName'?input:tag;}},
    localStorage:{getItem(){return 'Ian';},setItem(k,v){c.saved=v;}}};
  vm.runInNewContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],c);
  assert.equal(tag.textContent,'Ian');
  input.value='  ';listeners.input();assert.equal(tag.textContent,'Player');
  input.value='<b>Ian</b>';listeners.change();
  assert.equal(tag.textContent,'<b>Ian</b>');assert.equal(c.saved,'<b>Ian</b>');
  input.value='x'.repeat(25);listeners.change();assert.equal(tag.textContent.length,20);
  let stopped=false;listeners.keydown({stopPropagation(){stopped=true;}});assert(stopped);
});
